import mylib

c = mylib.svm("Yamaha")
print("Made a bike called: %s" % c.get_name())
