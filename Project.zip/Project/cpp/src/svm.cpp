#include "../include/mylib_bits/svm.hpp"

#include <iostream>

svm::svm(std::string name) {
    _name = name;
}

std::string svm::get_name() const {
    return _name;
}



