#include <string>

#ifndef MYLIB_H
#define MYLIB_H


class svm {

private:

    /// Name
    std::string _name;

public:

    /// Constructor
    svm(std::string name);

    /// Get name
    /// @return Name
    std::string get_name() const;

};



#endif
