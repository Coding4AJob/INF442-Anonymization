#include <mylib>

#include <iostream>

int main() {

    svm c("Yamaha");

    std::cout << "Made a car called: " << c.get_name() << std::endl;


    return 0;
}
