#include "../cpp/include/mylib_bits/svm.hpp"

#include <pybind11/stl.h>

#include <pybind11/pybind11.h>
namespace py = pybind11;

void init_svm(py::module &m) {
    
    py::class_<svm>(m, "svm")
    .def(py::init<std::string>(), py::arg("name"))
    .def("get_name",
         py::overload_cast<>( &svm::get_name, py::const_));
    
}
