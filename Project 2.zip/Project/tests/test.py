import mylib
import numpy as np
from random import sample

x = np.load("data/eng.testa.representation.npy")
y = np.load('data/eng.testa.true_labels.npy')

train_x = np.array(x)
train_y = np.zeros(shape=(train_x.shape[0],))
for i in range(train_x.shape[0]):
    if y[i] == 'I-PER':
        train_y[i] = 1
    else:
        train_y[i] = 0


#print(train_x.shape,train_y.shape)

#print(type(train_x),type(train_y))
print(len(np.where(train_y==0)))

LR = mylib.LogisticRegression(100,0.001,0.0)


LR.fit(train_x[0:-500,:],train_y[0:-500])


er = LR.score(train_x[-500:,:],train_y[-500:])

print("error_rate: ",er)
