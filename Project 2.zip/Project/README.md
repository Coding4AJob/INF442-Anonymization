## BUILD

1.  CPP
```
cd cpp
mkdir build
cd build
cmake ..
make
make install
```

2. Make test in CPP
```
cd cpp/tests
mkdir build
cd build
cmake ..
make
```
3. Make the pythob lib

replace the *USERNAME*
```
cd ..
cd build
cmake .. -DPYTHON_LIBRARY_DIR="/Users/USERNAME/opt/anaconda3/lib/python3.7/site-packages" -DPYTHON_EXECUTABLE="/Users/USERNAME/opt/anaconda3/bin/python3"
make
make install
```
